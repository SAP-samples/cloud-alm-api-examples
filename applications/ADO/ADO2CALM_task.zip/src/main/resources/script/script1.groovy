import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
       def map = message.getProperties();
       def status = map.get("status");
       
       def valueMapApi = ITApiFactory.getService(ValueMappingApi.class, null)
       def calmStatus = valueMapApi.getMappedValue('ADO', 'State', status, 'CALM', 'Status')
       message.setProperty("calmStatus", calmStatus);
       
       return message;
}